import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.feature_selection import RFE
from sklearn.model_selection import train_test_split, GridSearchCV, learning_curve
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from flask import Flask, request, render_template

app = Flask(__name__)

# Load the dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/parkinsons/parkinsons.data"
data = pd.read_csv(url)

# Preprocessing
X = data.drop(['name', 'status'], axis=1)
y = data['status']
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Feature selection using RFE with SVM
svm = SVC(kernel="linear")
rfe = RFE(estimator=svm, n_features_to_select=10)
X_rfe = rfe.fit_transform(X_scaled, y)
selected_features = X.columns[rfe.support_]

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X_rfe, y, test_size=0.2, random_state=42)

# Train the SVM model with GridSearchCV
parameters = {'kernel': ('linear', 'rbf'), 'C': [1, 10, 100]}
svc = SVC()
clf = GridSearchCV(svc, parameters, cv=5)
clf.fit(X_train, y_train)

# Evaluate the model
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

# Generate visualizations
def generate_visualizations():
    # Histograms
    data.hist(bins=20, figsize=(20, 15))
    plt.savefig('static/images/histograms.png')
    plt.close()

    # Box plots
    data.plot(kind='box', subplots=True, layout=(6, 6), figsize=(15, 15))
    plt.savefig('static/images/boxplots.png')
    plt.close()

    # Correlation Matrix
    numerical_data = data.select_dtypes(include=[np.number])
    correlation_matrix = numerical_data.corr()
    plt.figure(figsize=(14, 12))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
    plt.savefig('static/images/correlation_matrix.png')
    plt.close()

    # Learning Curve
    train_sizes, train_scores, test_scores = learning_curve(clf.best_estimator_, X_rfe, y, cv=5, n_jobs=-1, train_sizes=np.linspace(0.1, 1.0, 10))
    train_scores_mean = np.mean(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)

    plt.figure()
    plt.plot(train_sizes, train_scores_mean, 'o-', color='r', label='Training score')
    plt.plot(train_sizes, test_scores_mean, 'o-', color='g', label='Cross-validation score')
    plt.title('Learning Curve')
    plt.xlabel('Training Examples')
    plt.ylabel('Score')
    plt.legend(loc='best')
    plt.grid()
    plt.savefig('static/images/learning_curve.png')
    plt.close()

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(10, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Healthy', 'Parkinson\'s'], yticklabels=['Healthy', 'Parkinson\'s'])
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.savefig('static/images/confusion_matrix.png')
    plt.close()

generate_visualizations()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/form')
def form():
    return render_template('form.html', features=X.columns)

@app.route('/predict', methods=['POST'])
def predict():
    user_input = [float(request.form[feature]) for feature in X.columns]
    user_input_scaled = scaler.transform([user_input])
    user_input_selected = rfe.transform(user_input_scaled)
    prediction = clf.predict(user_input_selected)
    result = 'Parkinson\'s Disease' if prediction == 1 else 'Healthy'
    return render_template('results.html', prediction=result)

@app.route('/visualizations')
def visualizations():
    return render_template('visualizations.html')

@app.route('/model_info')
def model_info():
    return render_template('model_info.html', features=selected_features, accuracy=accuracy)

if __name__ == '__main__':
    app.run(debug=True)
